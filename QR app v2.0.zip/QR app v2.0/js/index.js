var x;
function startscan() {
                console.log('scanning');
            
                
                                              
                 
$('#scan').click(function(){
     var scanner = cordova.require("cordova/plugin/BarcodeScanner");
     
     
        scanner.scan( function (result) {
                if(result.text!=0){
                  x=result.text;
                 scan(x);

                }
                   
      });
          
});
$('#proceed').click(function(){
 x = document.getElementById("bid").value;
 
   if(x!=0){
   scan(x);
   }
});



}
function scan(e){
               
                    var i;
                    var qbid=e;
                   
                  
                    
                    //$(document).ready(function(){
                    
                  
                  jQuery.ajax({
                                 dataType: 'text',
                                 method: "POST",
                                 url: "http://www.scalex.tech/billing.php",
                                 crossDomain: true,
                                 data: {qbid:qbid},
                                 
                                 
                                
                                success: function (r) {
                               
                                  var total=0;
                                  
                                  r=JSON.parse(r);
                                  
                      
                        
                        $('#table').append('<tr>'+'<th>'+'Sr.NO'+'</th>'+'<th>'+'Item Name'+'</th>'+'<th>'+'Quantity'+'</th> '+'<th>'+'Price'+'</th>'+'<th>'+'Amount'+'</th>'+'</tr>');

                       // $('#info').append(z);4
                       for(i=0; i<r.length; i++){

                        var indiprice=r[i].price*1*r[i].quantity;
                        total=total+0+indiprice;
                       $('#table').append('<tr>'+'<th>'+(i+1)+'</th>'+'<th>'+r[i].itemname+'</th>'+'<th>'+r[i].quantity+'</th> '+'<th>'+r[i].price+'</th>'+'<th>'+indiprice+'</th>'+'</tr>');
   
                      };  

                       $('#total').append('Total Amount:'+total);
                        
                       
                                },
                                fail: function (t) { alert('error')}
                                
                    });
                        
}
function verify(){
              
                  var vid=x;
                    
                  
                    jQuery.ajax({
                                 dataType: 'text',
                                 method: "POST",
                                 url: "http://www.scalex.tech/billing.php",
                                 crossDomain: true,
                                 data: {vid:vid},
                                 
                                 
                                
                                success: function (r) {
                               
                                 myApp.alert(r);
                        
                                },
                                fail: function (t) { alert('error')}
                                
                    });

}