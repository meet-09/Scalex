/**
 * Framework7 3D Panels 1.0.0
 * Framework7 plugin to add 3d effect for side panels
 * 
 * http://www.idangero.us/framework7/plugins/
 * 
 * Copyright 2015, Vladimir Kharlampidi
 * The iDangero.us
 * http://www.idangero.us/
 * 
 * Licensed under MIT
 * 
 * Released on: August 22, 2015
 */
Framework7.prototype.plugins.panels3d=function(e,n){"use strict";function a(){n.enabled&&p.css({"-webkit-transform-origin":"100% center","transform-origin":"100% center"})}function r(){n.enabled&&p.css({"-webkit-transform-origin":"0% center","transform-origin":"0% center"})}function t(){p=o(".views"),d=o(".panel-left.panel-reveal"),f=o(".panel-right.panel-reveal"),d.on("open",a),f.on("open",r)}function s(e,a,r){n.enabled&&(a=o(a),a.hasClass("panel-reveal")&&(a.hasClass("panel-left")&&(i||(i=a[0].offsetWidth),p.transform("translate3d("+i*r+"px,0,0) rotateY("+-30*r+"deg)"),p.css({"-webkit-transform-origin":"100% center","transform-origin":"100% center"}),a.transform("translate3d("+-i*(1-r)+"px,0,0)")),a.hasClass("panel-right")&&(l||(l=a[0].offsetWidth),p.transform("translate3d("+-l*r+"px,0,0) rotateY("+30*r+"deg)"),p.css({"-webkit-transform-origin":"0% center","transform-origin":"0% center"}),a.transform("translate3d("+l*(1-r)+"px,0,0)"))))}n=n||{enabled:!0};var o=window.Dom7;e.panels3d={enable:function(){o("body").addClass("panels-3d"),n.enabled=!0},disable:function(){o("body").removeClass("panels-3d"),n.enabled=!1}},n.enabled&&o("body").addClass("panels-3d");var i,l,d,f,p;return{hooks:{appInit:t,swipePanelSetTransform:s}}};