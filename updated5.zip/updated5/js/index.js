 var total=0;
  var count=0;
   var itemname = "";
   var qtycount="";
   var payment= "Pending";
var executed = false;
var executed2=false;
var qarr1=[];
var qarr2=[];
 var itemlist=[];
function startscan() {
                console.log('scanning');
            
                var id=0;
                var book=[];
                var r;
                var z;                                 
                 
$("#scan").click(function(){  
     var scanner = cordova.require("cordova/plugin/BarcodeScanner");
     
                scanner.scan( function (result) { 
                   if(result.text!=0)
                   {
                    var p="We got a barcode \n" + "Result: " + result.text + "\n" + "Format: " + result.format + "\n" + "Cancelled: " + result.cancelled;
                    var txt=result.text;
                    myApp.alert("Product Scanned");
                    var s = txt;
                    
                    //$(document).ready(function(){
                    
                    
                       jQuery.ajax({
                                 dataType: 'text',
                                 method: "POST",
                                 url: "http://www.scalex.tech/ac26.php",
                                 crossDomain: true,
                                 data: {s:s},
                                 
                                 
                                
                                success: function (p) { 
                        z=p;
                        r= JSON.parse(z);
                       // $('#info').append(z);
                        print(z,id);
                        var booktemp = {
                               "id" : id,
                               "name":r[0].item_name,
                               "price" : r[0].price

                               
                            };  

                        book.push(booktemp); 
                        
                        
                        id++;
                        
                       
                                },
                                fail: function (t) { alert('error')}
                                
                    });
                        executed=false;
                        localStorage.setItem('qrcode', 0);
                }      
             });
      

    });

$("#payment").click(function(){ 		
  var q=0;
  var i;
  total=0;
  count=0;
  itemlist=[];
for (i=0; i<id; i++)
{
 
 

                  if( $( "#r"+i).length)
                  {
                      qarr1[i]=document.getElementById(i).value;
                      q = document.getElementById(i).value;

                  var p=book[i].price;
                  var n=book[i].name;
                  var itemtemp = {
                               "id" : book[i].id,
                               "name":n,
                               "price":p,
                               "qty":q
                               
                               
                            };  

                  itemlist.push(itemtemp); 
                                         
                                         var amount= p*q;
                                         qtycount+="-"+q;
                                         itemname+="-"+n;

                                       
                          
                              total=total+amount;
                              
                              
                              count++;
                              //count=count*1+q*1;
                              if(qarr1.equals(qarr2)==false){
                                executed=false;
                                executed2=false;

                              }
                              qarr2 = qarr1.slice();
                              }
                  else{
                                  
                                  q=0;
                                  
                              }

}

   localStorage.setItem('count', count);
    localStorage.setItem('total', total);
  
    if(executed2){     
  setTimeout(function(){
    var x=localStorage.getItem('count');
    var y=localStorage.getItem('total');
     
      $('#totalitem').append(x);
       $('#totalprice').append(y);
       
        var qrc=localStorage.getItem('qrcode');
       jQuery('#q').qrcode(qrc);
       $('#q').append("</br> or </br>"+qrc);
       

        }, 2000);
    }

    var b= JSON.stringify(itemlist);
                     
                     
     if (!executed) {
                
        jQuery.ajax({
                                 dataType: "text",
                                 method: "POST",
                                 url: "http://www.scalex.tech/billing.php",
                                 crossDomain: true,
                                 data: {b:b},
                                 
                                 
                                
                                success: function (p) { 
                                  
                                localStorage.setItem('qrcode', p);
                                executed = true;
                                 var x=localStorage.getItem('count');
                                  var y=localStorage.getItem('total');
                                   
                                    $('#totalitem').append(x);
                                     $('#totalprice').append(y);
                                     var qrc=localStorage.getItem('qrcode');
                                     jQuery('#q').qrcode(qrc);
                                     $('#q').append("</br> or </br>"+qrc);
                                     executed2=true;
                                },
                                fail: function (t) { alert('error')}
                                
                    });
      }

   

}); 
$("#gettotal").click(function(){


  var q=0;
  var i;
  total=0;
  count=0;
for (i=0; i<id; i++)
{
 
 

                  if( $( "#r"+i).length)
                  {
                      
                      q = document.getElementById(i).value;

                  var p=book[i].price;
                  var n=book[i].name;
                  var amount= p*q;
                  qtycount+="-"+q;
                  itemname+="-"+n;
                  total=total+amount;
                  count=count*1+q*1;
                              
                              }
                  else{
                                  
                                  q=0;
                                  
                              }

}

localStorage.setItem('amount',total);
var amt=localStorage.getItem('amount')
   $('#showtotal').empty();
   $('#showtotal').append(": Rs"+amt);
  });
}




function qr(){
  window.location='bh.html';
  var today = new Date();
  var dd = today.getDate();
  var mm = today.getMonth()+1; //January is 0!
  var yyyy = today.getFullYear();

  if(dd<10) {
      dd='0'+dd
  } 

  if(mm<10) {
      mm='0'+mm
  } 

  today = mm+'/'+dd+'/'+yyyy;
  
  var j=0;
  var b=localStorage.getItem('qrcode');
  if(localStorage.getItem('counter')>0){
  var counter=localStorage.getItem('counter')
  localStorage.setItem('id'+counter, counter);
  localStorage.setItem('date'+counter, today);
  localStorage.setItem('count'+counter, count);
  localStorage.setItem('total'+counter, total);
  localStorage.setItem('billingid'+counter, b);
  var temp=localStorage.getItem('id'+counter);
  
  var i="item"+counter;
  
  for(j=0; j<count; j++){
    
    var k=j+1;
    localStorage.setItem('item'+counter+k,itemlist[j].name);
    localStorage.setItem('price'+counter+k,itemlist[j].price);
    localStorage.setItem('qty'+counter+k,itemlist[j].qty);
  }
  counter++;
  localStorage.setItem('counter',counter);
  
 }  
 else{
  localStorage.setItem('counter', 1);
   qr();
 }

}
function bookingHistory(){

  var j=0;
  var c=localStorage.getItem('counter');
  
  
  
  for(j=1; j<c; j++){
    
    var temp=localStorage.getItem('id'+j);
    
    if(temp>0)
    {   
      var date=localStorage.getItem('date'+j);
      $('#bh').append('<ul>'+'<li>'+'<a href="bill.html" onclick="booking('+j+');" class="item-link item-content">'+'<div class="item-inner">'+'<div class="item-title">'+'Bill No. '+j+'</div>'+'<div class="item-after">'+'Date:'+date+'</div>'+'</div>'+'</a>'+'</li>'+'</ul>');

    }

  }  
}
function booking(c){
  setTimeout(function(){
    var cc=localStorage.getItem('count'+c);
    var tt=localStorage.getItem('total'+c);
    var bb=localStorage.getItem('billingid'+c);
    
    var j=0;
   $('#table').append('<tr>'+'<th>'+'Sr.NO'+'</th>'+'<th>'+'Item Name'+'</th>'+'<th>'+'Quantity'+'</th> '+'<th>'+'Price'+'</th>'+'<th>'+'Amount'+'</th>'+'</tr>');
    for(j=1; j<=cc; j++){
      var iname=localStorage.getItem('item'+c+j);
      
      var quan=localStorage.getItem('qty'+c+j);
      var prices=localStorage.getItem('price'+c+j);
      var indiqty=prices*1*quan;

      $('#table').append('<tr>'+'<th>'+j+'</th>'+'<th>'+iname+'</th>'+'<th>'+quan+'</th> '+'<th>'+prices+'</th>'+'<th>'+indiqty+'</th>'+'</tr>');

    }
    $('#btotal').append('Total Bill Amount:'+tt+'</br>'+'<strong>'+'Billing ID:'+bb+'</strong>');

  },1000);

}


function print(a,i){

//var id=i;
r= JSON.parse(a);

$('#list').append( '<li class="swipeout"  id="r'+i+'">'+
                          '<div class="item-content swipeout-content">'+
                            '<div class="item-inner"> '+
                              '<div class="item-title">'+
                             '<strong>'+'Item Name:'+'</strong>'+r[0].item_name+'<br>'+
                             
                             '<strong>'+'Price:'+'</strong>'+r[0].price+'<br>'+
                             
                              '<strong>'+'Quantity: '+'</strong>'+'<input type="text" id="'+i+'" placeholder="Type your quantity" name="quamtity">'+
                             '<hr>'+'<br>'+
                               '</div>'+
                           ' </div>'+
                         ' </div>'+
                          '<div class="swipeout-actions-right"><a href="#"id="delete"data-confirm="Are you sure you want to delete this item?" class="swipeout-delete ">'
                          +'Delete'+'</a>'+'</div>'+
                       ' </li>');
                       
                       
                       
}
Array.prototype.equals = function (array, strict) {
    if (!array)
        return false;

    if (arguments.length == 1)
        strict = true;

    if (this.length != array.length)
        return false;

    for (var i = 0; i < this.length; i++) {
        if (this[i] instanceof Array && array[i] instanceof Array) {
            if (!this[i].equals(array[i], strict))
                return false;
        }
        else if (strict && this[i] != array[i]) {
            return false;
        }
        else if (!strict) {
            return this.sort().equals(array.sort(), true);
        }
    }
    return true;
};
