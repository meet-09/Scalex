// Initialize app
var myApp = new Framework7({
    swipePanel:'left',
});


// If we need to use custom DOM library, let's save it to $$ variable:
var $$ = Dom7;

// Add view
var mainView = myApp.addView('.view-main', {
    // Because we want to use dynamic navbar, we need to enable it for this view:
    dynamicNavbar: true
});

// Handle Cordova Device Ready Event
$$(document).on('deviceready', function() {
    console.log("Device is ready!");
});


// Now we need to run the code that will be executed only for About page.

// Option 1. Using page callback for page (for "about" page in this case) (recommended way):
myApp.onPageInit('about', function (page) {
    // Do something here for "about" page

})

// Option 2. Using one 'pageInit' event handler for all pages:
$$(document).on('pageInit', function (e) {
    // Get page data from event data
    var page = e.detail.page;

    if (page.name === 'about') {
        // Following code will be executed for page with data-page attribute equal to "about"
        myApp.alert('Here comes About page');
    }
})

// Option 2. Using live 'pageInit' event handlers for each page
$$(document).on('pageInit', '.page[data-page="about"]', function (e) {
    // Following code will be executed for page with data-page attribute equal to "about"
    myApp.alert('Here comes About page');
})

//script for the pannels
$$('.open-left-panel').on('click', function (e) {
        // 'left' position to open Left panel
        myApp.openPanel('left');
    });
 
    $$('.open-right-panel').on('click', function (e) {
        // 'right' position to open Right panel
        myApp.openPanel('right');
    });
 
    $$('.panel-close').on('click', function (e) {
        myApp.closePanel();
    });
 
 
var welcomescreen_slides = [
  {
    id: 'slide0',
    picture: '<div class="tutorialicon">?</div>',
    text: 'Welcome to this tutorial. In the next steps we will guide you through a manual that will teach you how to use this app.'
  },
  {
    id: 'slide1',
    picture: '<div class="tutorialicon">?</div>',
    text: 'This is slide 2'
  },
  {
    id: 'slide2',
    picture: '<div class="tutorialicon">?</div>',
    text: 'This is slide 3'
  },
  {
    id: 'slide3',
    picture: '<div class="tutorialicon">?</div>',
    text: 'Thanks for reading! Enjoy this app.<br><br><a id="tutorial-close-btn" href="#">End Tutorial</a>'
  }
];
var pickerDevice = myApp.picker({
    input: '#picker-device',
    cols: [
        {
            textAlign: 'center',
            values: ['Airtel money', 'PayPal', 'Paytm', 'Card']
        }
    ]
});

$$('.open-indicator').on('click', function () {
    myApp.showIndicator();
    setTimeout(function () {
        myApp.hideIndicator();
    }, 2000);
});
var pickerDescribe = myApp.picker({
   
 input: '#picker-describe',
    rotateEffect: true,
    cols: [
        {
            textAlign: 'left',
            values: ('1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16').split(' ')
        },
        {
            values: ('').split(' ')
        },
    ]
});                






$$('.ac-1').on('click', function () {
    var buttons = [
        {
            text: 'Amount :',
            bold: true
        },
      
        {
            text: 'Back',
            color: 'red'
        },
    ];
    myApp.actions(buttons);
});







$$('.confirm-ok').on('click', function () {
    myApp.confirm('Are you sure?', function () {
        myApp.alert('You clicked Ok button');
    });
});
 